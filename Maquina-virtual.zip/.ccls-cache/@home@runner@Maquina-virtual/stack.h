#define MAX 100

typedef struct {
  int v[MAX];
  int top;
} Stack;

Stack*new_stack();
void push_stack(Stack *s, int x);
void print_stack(Stack *s);
int pop_stack(Stack *s);
int empty_stack(Stack *s);