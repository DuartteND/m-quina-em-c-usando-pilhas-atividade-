#include <stdlib.h>
#include <stdio.h>
#define MAX 100


typedef struct {
  int v[MAX];
  int topo;
} Stack;

//inicializar a pilha
Stack*new_stack(){
  Stack *s = (Stack*)
  malloc(sizeof(Stack));
  s -> topo=0;
  return s;
}
//empilhar
void push_stack(Stack *s, int x){
    s->v[s->topo] = x;
    s->topo++;
}
//desempilhar
int pop_stack( Stack *s){
  return s->v[--s->topo];
}
//mostrar a pilha
void print_stack(Stack *s){
  printf("------------PILHA------------------\n");
  for (int i =0; i< s->topo; i++){
    printf("\t          %d\n",s->v[i]);
  }printf("------------PILHA------------------\n");
}
//ver se a pilha está vazia
 int empty_stack(Stack *s){
   if (s->topo==0){
     return 1;
   } else{
     return 0;
   }
  
 }
