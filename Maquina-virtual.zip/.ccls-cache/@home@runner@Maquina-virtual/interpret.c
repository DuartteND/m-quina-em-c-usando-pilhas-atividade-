#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#define MAX 100
#define MEN -1

#include "interpret.h"
#include "stack.h"

Stack *s = NULL;

void stack_init () {
    s = new_stack(MAX);
}



void interpret (const char *source) {
    char op[10];
    char arg[10];

    sscanf (source, "%s%s", op, arg);
    
    printf("-Operação: %s\n", op);
    printf("-Argumento: %s\n",  arg);

  //operação push
  if (strcmp(op, "push") == 0){
    int value = atoi(arg);
    push_stack(s, value);
  //operação add 
  } else if (strcmp(op, "add") == 0){
  //ver se a pilha está vazia
      int r = empty_stack(s);
      if (r == 1){
        printf("Erro: Pilha Vazia\n");
      } 
      else {
    int arg1 = pop_stack(s);
    int arg2 = pop_stack(s);
    push_stack(s, arg1+arg2);
        }
  //opreção sub
  } else if (strcmp(op, "sub")== 0){
  //ver se a pilha está vazia 
    int r = empty_stack(s);
      if (r == 1){
        printf("Erro: Pilha Vazia\n");
      }else {
    int arg1 = pop_stack(s);
    int arg2 = pop_stack(s);
    int value = arg1 - arg2;
    push_stack(s,abs(value));
      }
    //operaçãp div
  } else if(strcmp(op, "div")== 0){
   // ver se a pilha está vazia 
    int r = empty_stack(s);
    if (r == 1){
        printf("Erro: Pilha Vazia\n");
      } else {
    float arg1 = pop_stack(s);
    float arg2 = pop_stack(s);
    float value = arg1 / arg2;
    push_stack(s, value);
      }
  //operação mul
  } else if (strcmp(op, "mul")== 0){
  //ver se a pilha está vazia 
    int r = empty_stack(s);
    if (r == 1){
        printf("Erro: Pilha Vazia\n");
      } else {
    int arg1 = pop_stack(s);
    int arg2 = pop_stack(s);
    int value = arg1 * arg2;
    push_stack(s,value);
      }
  //operção print 
  }else if (strcmp(op, "print") == 0){
    print_stack(s);
  //operação pop (quase ia me esquecendo dela kk)
  } else if(strcmp(op, "pop")== 0){
  //ver se a pilha está vazia 
    int r = empty_stack(s);
      if (r == 1){
        printf("Erro: Pilha Vazia\n");
      }else {
    pop_stack(s);
  }
  }else{
    printf("Operação inválida\n");
  }
}  